# Recursos y Medios Didácticos · Aula virtual

Proyecto listo para publicar con GitHub Pages.

## Publicar
1. Crear un repositorio llamado `recursos-medios-didacticos`.
2. Subir todos los archivos y carpetas.
3. GitHub → Settings → Pages.
4. Source: Deploy from a branch.
5. Branch: `main` y carpeta `/root`.
6. Guardar.

## Moodle
Una vez publicada la web, incrustarla en una página/recurso con:

```html
<iframe src="https://TU-USUARIO.github.io/recursos-medios-didacticos/"
width="100%" height="1000" style="border:0;border-radius:16px;"></iframe>
```

## Fechas
La portada compara la fecha del navegador con las fechas configuradas en `script.js`.
La clase 12 está configurada para el 09/11/2026, según la confirmación de la cátedra.

Nota: el plan original ubica la clase 3 el 31/08 y la clase 2 el 01/09. Se conserva ese dato tal como figura/confirmaste, aunque el orden cronológico queda invertido.
